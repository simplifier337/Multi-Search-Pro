(async function () {
  const groupsContainer = document.getElementById("groupsContainer");
  const addGroupBtn = document.getElementById("addGroupBtn");
  const newGroupName = document.getElementById("newGroupName");
  const groupOrderEl = document.getElementById("groupOrder");
  const exportAllBtn = document.getElementById("exportAll");
  const importAllBtn = document.getElementById("importAll");
  const resetDefaultsBtn = document.getElementById("resetDefaults");

  const bg = (m) => (chrome?.runtime || browser.runtime).sendMessage(m);

  // Per-domain icon URL cache so we don't retry the same chain on re-render
  const iconCache = new Map();

  // DDG returns 404 for missing icons — use HEAD to check before setting src
  const ddgCache = new Map();
  async function ddgHasIcon(domain) {
    if (ddgCache.has(domain)) return ddgCache.get(domain);
    try {
      const resp = await fetch(`https://icons.duckduckgo.com/ip3/${domain}.ico`, { method: "HEAD" });
      ddgCache.set(domain, resp.ok);
      return resp.ok;
    } catch(e) {
      ddgCache.set(domain, false);
      return false;
    }
  }

  const googleCache = new Map();
  async function googleHasIcon(domain) {
    if (googleCache.has(domain)) return googleCache.get(domain);
    try {
      const resp = await fetch(`https://www.google.com/s2/favicons?domain=${domain}&sz=64`, { method: "HEAD" });
      googleCache.set(domain, resp.ok);
      return resp.ok;
    } catch(e) {
      googleCache.set(domain, false);
      return false;
    }
  }

  let CONFIG = await bg({ type: "GET_CONFIG" });

  async function saveConfig() {
    await bg({ type: "SAVE_CONFIG", config: CONFIG });
    try {
      await chrome.storage.local.set({ config: CONFIG });
    } catch (e) {
      console.error("Failed to save config", e);
    }
  }

  function createEngineRow(groupId, engId, eng, index) {
    const row = document.createElement("div");
    row.className = "eng-row";
    row.dataset.engid = engId;
    row.draggable = true;

    const handle = document.createElement("div");
    handle.className = "handle";
    handle.title = "Drag to reorder engine";
    handle.textContent = "≡";
    handle.style.fontSize = "16px";

    const fav = document.createElement("div");
    fav.className = "fav";

    const img = document.createElement("img");
    img.alt = eng.name;

    let domain = "";
    try {
      domain = new URL(eng.url).hostname;
    } catch {}

    if (iconCache.has(domain)) {
      img.src = iconCache.get(domain);
    } else {
      const fallbacks = [
        `icons/default.png`
      ];

      let attempt = 0;
      function tryNext() {
        if (attempt < fallbacks.length) {
          img.src = fallbacks[attempt++];
        }
      }

      img.onerror = () => tryNext();
      img.onload = () => {
        if (img.src && !img.src.endsWith("default.png")) {
          iconCache.set(domain, img.src);
        }
      };

      // Check DDG then Google via HEAD — only use if they have a real icon
      (async () => {
        const hasDDG = await ddgHasIcon(domain);
        if (hasDDG) {
          img.src = `https://icons.duckduckgo.com/ip3/${domain}.ico`;
          return;
        }
        const hasGoogle = await googleHasIcon(domain);
        if (hasGoogle) {
          img.src = `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;
          return;
        }
        tryNext();
      })();
    }
    fav.appendChild(img);

    const nameI = document.createElement("input");
    nameI.className = "name";
    nameI.value = eng.name;
    nameI.addEventListener("input", () => eng.name = nameI.value);

    const urlI = document.createElement("input");
    urlI.className = "url";
    urlI.value = eng.url;
    urlI.addEventListener("input", () => eng.url = urlI.value);

    const enabledChk = document.createElement("input");
    enabledChk.type = "checkbox";
    enabledChk.checked = (CONFIG.groups[groupId].enabledEngines || []).includes(engId);
    enabledChk.title = "Include in searches for this group";
    enabledChk.addEventListener("change", async () => {
      if (enabledChk.checked) {
        CONFIG.groups[groupId].enabledEngines = CONFIG.groups[groupId].enabledEngines || [];
        if (!CONFIG.groups[groupId].enabledEngines.includes(engId)) CONFIG.groups[groupId].enabledEngines.push(engId);
      } else {
        CONFIG.groups[groupId].enabledEngines = (CONFIG.groups[groupId].enabledEngines || []).filter(x => x !== engId);
      }
      await saveConfig();
    });

    const saveBtn = document.createElement("button");
    saveBtn.className = "btn";
    saveBtn.textContent = "Save";
    saveBtn.addEventListener("click", async () => {
      if (!urlI.value.includes("%s")) return alert("URL must contain %s");
      CONFIG.engines[engId].name = nameI.value.trim() || "Unnamed";
      CONFIG.engines[engId].url = urlI.value.trim();
      await saveConfig();
      renderAll();
    });

    const removeBtn = document.createElement("button");
    removeBtn.className = "btn danger";
    removeBtn.textContent = "Remove";
    removeBtn.addEventListener("click", async () => {
      if (!confirm("Remove engine from group? This deletes engine entirely.")) return;
      delete CONFIG.engines[engId];
      for (const g of Object.keys(CONFIG.groups)) {
        CONFIG.groups[g].assignedEngines = (CONFIG.groups[g].assignedEngines || []).filter(x => x !== engId);
        CONFIG.groups[g].enabledEngines = (CONFIG.groups[g].enabledEngines || []).filter(x => x !== engId);
      }
      await saveConfig();
      renderAll();
    });

    row.append(handle, fav, nameI, urlI, enabledChk, saveBtn, removeBtn);

    row.addEventListener("dragstart", (e) => {
      e.dataTransfer.setData("text/plain", JSON.stringify({ type: "engine", groupId, engId }));
      row.classList.add("dragging");
    });
    row.addEventListener("dragend", () => row.classList.remove("dragging"));

    return row;
  }

  function renderGroupsLeft() {
    groupsContainer.innerHTML = "";
    const order = CONFIG.groupOrder && CONFIG.groupOrder.length ? CONFIG.groupOrder : Object.keys(CONFIG.groups || {});

    for (const gid of order) {
      const g = CONFIG.groups[gid];
      if (!g) continue;

      const block = document.createElement("div");
      block.className = "group-settings";

      const header = document.createElement("div");
      header.style.display = "flex";
      header.style.justifyContent = "space-between";
      header.style.alignItems = "center";

      const nameI = document.createElement("input");
      nameI.value = g.name;
      nameI.addEventListener("change", async () => {
        CONFIG.groups[gid].name = nameI.value.trim() || "Unnamed";
        await saveConfig();
        renderAll();
      });

      const delBtn = document.createElement("button");
      delBtn.className = "btn danger";
      delBtn.textContent = "Delete";
      delBtn.addEventListener("click", async () => {
        if (!confirm("Delete group?")) return;
        delete CONFIG.groups[gid];
        CONFIG.groupOrder = (CONFIG.groupOrder || []).filter(x => x !== gid);
        await saveConfig();
        renderAll();
      });

      header.append(nameI, delBtn);
      block.appendChild(header);

      const engListDiv = document.createElement("div");
      engListDiv.style.marginTop = "8px";
      const assigned = g.assignedEngines || [];
      let count = 0;

      assigned.forEach((eid) => {
        const eng = CONFIG.engines[eid];
        if (!eng) return;

        const row = createEngineRow(gid, eid, eng);
        engListDiv.appendChild(row);

        count++;
        if (count % 7 === 0 && count < assigned.length) {
          const divider = document.createElement("div");
          divider.className = "divider";
          engListDiv.appendChild(divider);
        }
      });

      // drag & drop
      engListDiv.addEventListener("dragover", (e) => {
        e.preventDefault();
        const dragging = engListDiv.querySelector(".dragging");
        const after = getDragAfterElement(engListDiv, e.clientY);
        if (!dragging) return;
        if (after == null) engListDiv.appendChild(dragging);
        else engListDiv.insertBefore(dragging, after);
      });

      engListDiv.addEventListener("drop", async (e) => {
        e.preventDefault();
        const ids = Array.from(engListDiv.querySelectorAll(".eng-row")).map(r => r.dataset.engid);
        CONFIG.groups[gid].assignedEngines = ids;
        CONFIG.groups[gid].enabledEngines = (CONFIG.groups[gid].enabledEngines || []).filter(x => ids.includes(x));
        await saveConfig();
        renderAll();
      });

      block.appendChild(engListDiv);

      // add new engine
      const addRow = document.createElement("div");
      addRow.style.marginTop = "10px";
      addRow.style.display = "flex";
      addRow.style.gap = "8px";
      addRow.style.alignItems = "center";

      const nameNew = document.createElement("input");
      nameNew.placeholder = "Engine name";
      nameNew.style.width = "180px";

      const urlNew = document.createElement("input");
      urlNew.placeholder = "URL with %s";
      urlNew.style.flex = "1";

      const addBtn = document.createElement("button");
      addBtn.className = "btn";
      addBtn.textContent = "Add";
      addBtn.addEventListener("click", async () => {
        const name = nameNew.value.trim() || "New Engine";
        const url = urlNew.value.trim();
        if (!url.includes("%s")) return alert("URL must contain %s");

        const resp = await bg({ type: "CREATE_ENGINE", name, url, groupId: gid, enable: false });
        if (resp && resp.ok) {
          CONFIG.engines[resp.engine.id] = resp.engine;
          nameNew.value = "";
          urlNew.value = "";
          await saveConfig();
          renderAll();
        } else {
          alert("Failed to create engine");
        }
      });

      addRow.append(nameNew, urlNew, addBtn);
      block.appendChild(addRow);

      groupsContainer.appendChild(block);
    }
  }

  // right side group order
  function renderGroupOrder() {
    groupOrderEl.innerHTML = "";
    const order = CONFIG.groupOrder || Object.keys(CONFIG.groups || {});

    order.forEach((gid) => {
      const g = CONFIG.groups[gid];
      if (!g) return;

      const row = document.createElement("div");
      row.style.display = "flex";
      row.style.alignItems = "center";
      row.style.justifyContent = "space-between";
      row.style.gap = "8px";
      row.style.padding = "6px";
      row.style.border = "1px solid rgba(0,0,0,0.04)";
      row.style.borderRadius = "6px";
      row.draggable = true;
      row.dataset.gid = gid;

      const left = document.createElement("div");
      left.style.display = "flex";
      left.style.alignItems = "center";
      left.style.gap = "8px";

      const handle = document.createElement("div");
      handle.className = "handle";
      handle.textContent = "≡";
      handle.style.fontSize = "16px";

      const label = document.createElement("div");
      label.textContent = g.name;

      left.append(handle, label);

      row.append(left);
      groupOrderEl.appendChild(row);

      row.addEventListener("dragstart", (e) => {
        e.dataTransfer.setData("text/plain", JSON.stringify({ type: "group", gid }));
        row.classList.add("dragging");
      });
      row.addEventListener("dragend", () => row.classList.remove("dragging"));
    });

    groupOrderEl.addEventListener("dragover", (e) => {
      e.preventDefault();
      const after = getDragAfterElement(groupOrderEl, e.clientY);
      const dragging = groupOrderEl.querySelector(".dragging");
      if (!dragging) return;
      if (after == null) groupOrderEl.appendChild(dragging);
      else groupOrderEl.insertBefore(dragging, after);
    });

    groupOrderEl.addEventListener("drop", async (e) => {
      e.preventDefault();
      const ids = Array.from(groupOrderEl.children).map(c => c.dataset.gid);
      CONFIG.groupOrder = ids;
      await saveConfig();
      renderAll();
    });
  }

  function getDragAfterElement(container, y) {
    const draggableElements = [...container.querySelectorAll(":scope > *:not(.dragging)")];
    let closest = { offset: Number.NEGATIVE_INFINITY, element: null };
    for (const child of draggableElements) {
      const box = child.getBoundingClientRect();
      const offset = y - box.top - box.height / 2;
      if (offset < 0 && offset > closest.offset) {
        closest = { offset, element: child };
      }
    }
    return closest.element;
  }

  // export / import
  exportAllBtn.addEventListener("click", async () => {
    const cfg = await bg({ type: "GET_CONFIG" });
    const txt = JSON.stringify(cfg, null, 2);
    const blob = new Blob([txt], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "multi-search-pro-config.json";
    a.click();
    URL.revokeObjectURL(url);
  });

  importAllBtn.addEventListener("click", () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json,application/json";
    input.addEventListener("change", async () => {
      const file = input.files[0];
      if (!file) return;
      try {
        const txt = await file.text();
        const data = JSON.parse(txt);
        await bg({ type: "SAVE_CONFIG", config: data });
        CONFIG = data;
        renderAll();
        alert("Config imported successfully.");
      } catch (e) {
        alert("Failed to import — make sure it\'s a valid Multi-Search Pro config file.");
      }
    });
    input.click();
  });

  resetDefaultsBtn.addEventListener("click", async () => {
    if (!confirm("Reset to defaults? This will overwrite current config.")) return;
    await bg({ type: "RESET_DEFAULTS" });
    CONFIG = await bg({ type: "GET_CONFIG" });
    renderAll();
  });

  // create group
  addGroupBtn.addEventListener("click", async () => {
    const name = newGroupName.value.trim();
    if (!name) return alert("Enter group name");
    const id = name.toLowerCase().replace(/[^a-z0-9]+/g, "_");
    if (CONFIG.groups[id]) return alert("Group exists");
    CONFIG.groups[id] = { name, assignedEngines: [], enabledEngines: [] };
    CONFIG.groupOrder = CONFIG.groupOrder || [];
    CONFIG.groupOrder.push(id);
    await saveConfig();
    newGroupName.value = "";
    renderAll();
  });

  function renderAll() {
    renderGroupsLeft();
    renderGroupOrder();
  }

  renderAll();
  iconCache.clear();
  ddgCache.clear();
  googleCache.clear();

  // storage listener
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.config) {
      CONFIG = changes.config.newValue;
      renderAll();
    }
  });

})();