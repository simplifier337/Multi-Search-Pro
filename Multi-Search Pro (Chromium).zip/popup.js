(async function () {
  const queryEl = document.getElementById("query");
  const groupsEl = document.getElementById("groups");
  const scrollEl = document.querySelector(".groups-scroll");
  const searchBtn = document.getElementById("searchBtn");
  const settingsBtn = document.getElementById("settingsBtn");
  const throttleEl = document.getElementById("throttle");
  const maxTabsEl = document.getElementById("maxTabs");
  const keepOpenEl = document.getElementById("keepOpen");
  const showUncheckedEl = document.getElementById("showUnchecked");

  const bg = (m) => chrome.runtime.sendMessage(m);

  async function loadConfig() {
    try { return await bg({ type: "GET_CONFIG" }); }
    catch { return null; }
  }

  async function loadPopupState() {
    try {
      const r = await bg({ type: "GET_POPUP_STATE" });
      return r || {};
    } catch {
      const s1 = await chrome.storage.session.get("popupState");
      if (s1.popupState) return s1.popupState;
      const s2 = await chrome.storage.local.get("popupState");
      return s2.popupState || {};
    }
  }

  let cfg = await loadConfig();
  if (!cfg) {
    groupsEl.innerHTML = "<div style='padding:12px;color:#a11;background:#fee;border-radius:6px'>Failed to load config. Open settings.</div>";
    settingsBtn.addEventListener("click", () => chrome.runtime.openOptionsPage());
    return;
  }

  let state = await loadPopupState();
  state = Object.assign({ query: "" }, state);
  if (!state.collapsed) state.collapsed = {};
  if (!state.selectedGroups) state.selectedGroups = {};
  if (state.keepOpen == null) state.keepOpen = true;
  if (typeof state.showUnchecked !== "boolean") state.showUnchecked = true;

  if (state._collapsedDefaultsSet === undefined) {
    const order = cfg.groupOrder?.length ? cfg.groupOrder : Object.keys(cfg.groups);
    order.forEach(gid => state.collapsed[gid] = true);
    state._collapsedDefaultsSet = true;
  }

  if (!Object.keys(state.selectedGroups).length) {
    if (cfg.groupOrder?.includes("general")) state.selectedGroups.general = true;
    else if (cfg.groupOrder?.[0]) state.selectedGroups[cfg.groupOrder[0]] = true;
  }

  keepOpenEl.checked = state.keepOpen;
  showUncheckedEl.checked = state.showUnchecked;
  throttleEl.value = state.throttleMs || 120;
  maxTabsEl.value = state.maxTabs || 50;
  if (state.query) queryEl.value = state.query;

  async function savePopupState() {
    const toSave = {
      query: queryEl.value,
      collapsed: state.collapsed,
      selectedGroups: state.selectedGroups,
      keepOpen: keepOpenEl.checked,
      showUnchecked: showUncheckedEl.checked,
      throttleMs: parseInt(throttleEl.value, 10) || 120,
      maxTabs: parseInt(maxTabsEl.value, 10) || 50,
      _collapsedDefaultsSet: true,
      scrollTop: scrollEl.scrollTop
    };
    Object.assign(state, toSave);
    await bg({ type: "SAVE_POPUP_STATE", state: toSave });
  }

  async function toggleEngineEnabled(groupId, engineId, enabled) {
    const g = cfg.groups[groupId] ||= {};
    g.enabledEngines ||= [];

    if (enabled) {
      if (!g.enabledEngines.includes(engineId)) g.enabledEngines.push(engineId);
    } else {
      g.enabledEngines = g.enabledEngines.filter(x => x !== engineId);
    }

    await bg({ type: "SAVE_CONFIG", config: cfg });
  }

  async function openSpecificEngines(ids, q) {
    await bg({
      type: "OPEN_SPECIFIC_ENGINES",
      engines: ids,
      query: q || "",
      throttleMs: parseInt(throttleEl.value, 10) || 120,
      maxTabs: parseInt(maxTabsEl.value, 10) || 50
    });
  }

  function renderGroups() {
    groupsEl.innerHTML = "";
    let visualIndex = 0;
    const order = cfg.groupOrder?.length ? cfg.groupOrder : Object.keys(cfg.groups);

    for (const gid of order) {
      const g = cfg.groups[gid];
      if (!g) continue;

      const block = document.createElement("div");
      block.className = "group";

      const header = document.createElement("div");
      header.className = "group-header";

      const left = document.createElement("div");
      left.className = "group-left";

      const grpChk = document.createElement("input");
      grpChk.type = "checkbox";
      grpChk.className = "grp-chk";
      grpChk.checked = !!state.selectedGroups[gid];
      grpChk.addEventListener("change", (e) => {
        state.selectedGroups[gid] = e.target.checked;
        savePopupState();
      });

        const titleWrapper = document.createElement("div");
        titleWrapper.style.display = "flex";
        titleWrapper.style.alignItems = "center";
        titleWrapper.style.gap = "8px";

        const title = document.createElement("div");
        title.textContent = g.name;
        title.style.fontWeight = "600";
        title.style.fontSize = "16px";
        title.style.color = "inherit";

        const totalEngines = (g.assignedEngines || []).length;
        const checkedCount = (g.enabledEngines || []).length;

        const countSpan = document.createElement("span");
        countSpan.className = "small";
        countSpan.textContent = `${totalEngines} engines • ${checkedCount} checked`;


        titleWrapper.append(title, countSpan);
        left.append(grpChk, titleWrapper);

      const right = document.createElement("div");
      right.className = "group-header-buttons";

const goBtn = document.createElement("button");
goBtn.type = "button";
goBtn.className = "group-go-btn";
goBtn.textContent = "Go";

goBtn.addEventListener("click", async () => {
  const q = queryEl.value.trim();

  const enabledInOrder = (g.assignedEngines || []).filter(id =>
    g.enabledEngines?.includes(id)
  );

  if (!enabledInOrder.length) {
    return alert("No enabled engines in this group.");
  }

  await openSpecificEngines(enabledInOrder, q);

  if (!keepOpenEl.checked) window.close();
});

      const collapseBtn = document.createElement("button");
      collapseBtn.type = "button";
      collapseBtn.className = "collapse-btn";
      collapseBtn.textContent = state.collapsed[gid] ? "Expand" : "Collapse";
      collapseBtn.addEventListener("click", () => {
        state.collapsed[gid] = !state.collapsed[gid];
        collapseBtn.textContent = state.collapsed[gid] ? "Expand" : "Collapse";
        savePopupState();
        renderGroups();
      });

      right.append(goBtn, collapseBtn);
      header.append(left, right);
      block.appendChild(header);

      const iconRow = document.createElement("div");
      iconRow.className = "icon-row";

      const showAll = showUncheckedEl.checked;
      const list = g.assignedEngines?.length ? g.assignedEngines : g.enabledEngines || [];

      for (const eid of list) {
        const e = cfg.engines[eid];
        if (!e) continue;
        if (!showAll && !g.enabledEngines?.includes(eid)) continue;
        e._visualOrder = visualIndex++;

        const tile = document.createElement("div");
        tile.className = "icon-tile";
        tile.title = e.name;

        const chkWrap = document.createElement("div");
        chkWrap.className = "chk-wrap";

        const chk = document.createElement("input");
        chk.type = "checkbox";
        chk.className = "eng-chk";
        chk.checked = g.enabledEngines?.includes(eid);
        chk.addEventListener("change", async () => {
          await toggleEngineEnabled(gid, eid, chk.checked);
          cfg = await bg({ type: "GET_CONFIG" });
          renderGroups();
        });

        chkWrap.appendChild(chk);
        tile.appendChild(chkWrap);

        let domain = "";
        try {
          domain = new URL(e.url).hostname;
        } catch {}

        const img = document.createElement("img");

        // List of known bad DDG placeholder patterns
        const DDG_BAD_PATTERNS = [
          "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABJklEQVQ4jWPt0",
          "PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdm",
          "data:image/svg+xml"
        ];

        function isDDGErrorIcon(url) {
          if (!url) return false;
          return DDG_BAD_PATTERNS.some(p => url.includes(p));
        }

        const candidates = [
          e.icon,
          `https://icons.duckduckgo.com/ip3/${domain}.ico`,
          `https://www.google.com/s2/favicons?domain=${domain}&sz=64`,
          `https://favicon.vemetric.com/${domain}`,
          `https://favicon.id/${domain}`
        ].filter(Boolean);

        let attempt = 0;
        function tryNext() {
          while (attempt < candidates.length) {
            const url = candidates[attempt++];
            if (isDDGErrorIcon(url)) {
              continue;
            }
            img.src = url;
            return;
          }
          img.src = "icons/default.png";
        }

        img.onerror = tryNext;

        tryNext();
        tile.appendChild(img);

        const lbl = document.createElement("div");
        lbl.className = "label";
        lbl.textContent = e.name;
        tile.appendChild(lbl);

        tile.addEventListener("click", (ev) => {
          if (ev.target.tagName === "INPUT") return;
          openSpecificEngines([eid], queryEl.value.trim());
          if (!keepOpenEl.checked) window.close();
        });

        iconRow.appendChild(tile);
      }

      iconRow.style.display = state.collapsed[gid] ? "none" : "flex";
      block.appendChild(iconRow);

      groupsEl.appendChild(block);
    }
  }

  // ----- SEARCH BUTTON -----
  searchBtn.addEventListener("click", async () => {
    const q = queryEl.value.trim();
    if (!q) return alert("Enter a search term");

    const selected = Object.keys(state.selectedGroups).filter((g) => state.selectedGroups[g]);
    if (!selected.length) return alert("Select at least one group");

    const resp = await bg({
      type: "OPEN_SEARCH_TABS",
      query: q,
      groups: selected,
      throttleMs: parseInt(throttleEl.value, 10) || 120,
      maxTabs: parseInt(maxTabsEl.value, 10) || 50
    });

    if (resp?.ok === false && resp.reason === "TOO_MANY") {
      if (confirm(`Open ${resp.count} tabs?`)) {
        await bg({
          type: "OPEN_SEARCH_TABS",
          query: q,
          groups: selected,
          force: true
        });
      }
    } else if (resp?.ok) {
      await savePopupState();
      if (!keepOpenEl.checked) window.close();
    }
  });

  settingsBtn.addEventListener("click", () => chrome.runtime.openOptionsPage());
  keepOpenEl.addEventListener("change", savePopupState);
  showUncheckedEl.addEventListener("change", () => { savePopupState(); renderGroups(); });
  throttleEl.addEventListener("change", savePopupState);
  maxTabsEl.addEventListener("change", savePopupState);
  queryEl.addEventListener("input", savePopupState);
  scrollEl.addEventListener("scroll", savePopupState);

  renderGroups();
  if (state.scrollTop) scrollEl.scrollTop = state.scrollTop;
  savePopupState();

  chrome.storage.onChanged.addListener((changes) => {
    if (changes.config) {
  Object.assign(cfg, changes.config.newValue);
  renderGroups();
}
    if (changes.popupState?.newValue) {
      Object.assign(state, changes.popupState.newValue);
      keepOpenEl.checked = !!state.keepOpen;
      showUncheckedEl.checked = !!state.showUnchecked;
      queryEl.value = state.query || "";
      renderGroups();
    }
  });
})();